/**
 * NOTICE: This file is copied from @react-native-oh-tpl/async-storage and adapted.
 *
 * AsyncStorage was initially part of React Native, which is why this copyright header is used.
 * It was later extracted and moved to a separate library.
 * @react-native-oh-tpl/async-storage is based on @react-native-async-storage/async-storage and has been slightly adapted for OHOS.
 */

import type { ErrorLike } from "./types";

export function convertError(error?: ErrorLike): Error | null {
  if (!error) {
    return null;
  }

  const out = new Error(error.message) as Error & ErrorLike;
  out["key"] = error.key;
  return out;
}

export function convertErrors(
  errs?: ErrorLike[]
): ReadonlyArray<Error | null> | null {
  const errors = ensureArray(errs);
  return errors ? errors.map((e) => convertError(e)) : null;
}

function ensureArray(e?: ErrorLike | ErrorLike[]): ErrorLike[] | null {
  if (Array.isArray(e)) {
    return e.length === 0 ? null : e;
  } else if (e) {
    return [e];
  } else {
    return null;
  }
}
