/**
 * NOTICE: This file is copied from @react-native-oh-tpl/async-storage and adapted.
 *
 * AsyncStorage was initially part of React Native, which is why this copyright header is used.
 * It was later extracted and moved to a separate library.
 * @react-native-oh-tpl/async-storage is based on @react-native-async-storage/async-storage and has been slightly adapted for OHOS.
 */

import AsyncStorage from "./AsyncStorage";
import type { AsyncStorageHook } from "./types";

export function useAsyncStorage(key: string): AsyncStorageHook {
  return {
    getItem: (...args) => AsyncStorage.getItem(key, ...args),
    setItem: (...args) => AsyncStorage.setItem(key, ...args),
    mergeItem: (...args) => AsyncStorage.mergeItem(key, ...args),
    removeItem: (...args) => AsyncStorage.removeItem(key, ...args),
  };
}
