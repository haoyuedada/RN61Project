/**
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * NOTICE: This file is copied from @react-native-oh-tpl/async-storage and adapted.
 *
 * AsyncStorage was initially part of React Native, which is why this copyright header is used.
 * It was later extracted and moved to a separate library.
 * @react-native-oh-tpl/async-storage is based on @react-native-async-storage/async-storage and has been slightly adapted for OHOS.
 */

import { convertError, convertErrors } from "./helpers";
import RCTAsyncStorage from "../../src/private/specs/AsyncStorage";
import type {
  CallbackWithResult,
  Callback,
  MultiCallback,
  MultiGetCallback,
  ErrorLike,
  KeyValuePair,
} from "./types";

if (!RCTAsyncStorage) {
  throw new Error("AsyncStorage is null");
}

const AsyncStorage = (() => {
  return {
    getItem: (
      key: string,
      callback?: CallbackWithResult<string>
    ): Promise<string | null> => {
      return new Promise((resolve, reject) => {
        RCTAsyncStorage.multiGet(
          [key],
          (errors?: ErrorLike[], result?: string[][]) => {
            const value = result?.[0]?.[1] ? result[0][1] : null;
            const errs = convertErrors(errors);
            callback?.(errs?.[0], value);
            if (errs) {
              reject(errs[0]);
            } else {
              resolve(value);
            }
          }
        );
      });
    },

    setItem: (
      key: string,
      value: string,
      callback?: Callback
    ): Promise<null> => {
      return new Promise((resolve, reject) => {
        RCTAsyncStorage.multiSet([[key, value]], (errors?: ErrorLike[]) => {
          const errs = convertErrors(errors);
          callback?.(errs?.[0]);
          if (errs) {
            reject(errs[0]);
          } else {
            resolve(null);
          }
        });
      });
    },

    removeItem: (key: string, callback?: Callback): Promise<null> => {
      return new Promise((resolve, reject) => {
        RCTAsyncStorage.multiRemove([key], (errors?: ErrorLike[]) => {
          const errs = convertErrors(errors);
          callback?.(errs?.[0]);
          if (errs) {
            reject(errs[0]);
          } else {
            resolve(null);
          }
        });
      });
    },

    mergeItem: (
      key: string,
      value: string,
      callback?: Callback
    ): Promise<null> => {
      return new Promise((resolve, reject) => {
        RCTAsyncStorage.multiMerge([[key, value]], (errors?: ErrorLike[]) => {
          const errs = convertErrors(errors);
          callback?.(errs?.[0]);
          if (errs) {
            reject(errs[0]);
          } else {
            resolve(null);
          }
        });
      });
    },

    clear: (callback?: Callback): Promise<null> => {
      return new Promise((resolve, reject) => {
        RCTAsyncStorage.clear((errors?: ErrorLike[]) => {
          const errs = convertErrors(errors);
          callback?.(errs?.[0]);
          if (errs) {
            reject(errs[0]);
          } else {
            resolve(null);
          }
        });
      });
    },

    getAllKeys: (
      callback?: CallbackWithResult<readonly string[]>
    ): Promise<readonly string[]> => {
      return new Promise((resolve, reject) => {
        RCTAsyncStorage.getAllKeys(
          (errors?: ErrorLike[], result?: [string, string][]) => {
            const errs = convertErrors(errors);
            const keys = result?.map(([key]) => key);
            callback?.(errs?.[0], keys);
            if (errs) {
              reject(errs[0]);
            } else {
              resolve(keys ?? []);
            }
          }
        );
      });
    },

    flushGetRequests: () => undefined,

    multiGet: (
      keys: readonly string[],
      callback?: MultiGetCallback
    ): Promise<readonly KeyValuePair[]> => {
      return new Promise((resolve) => {
        RCTAsyncStorage.multiGet(
          keys.map((key) => key as string),
          (errors?: ErrorLike[], result?: string[][]) => {
            const map: Record<string, string | null> = {};
            result?.forEach(([key, value]) => {
              const normalized = value === "" ? null : value;
              map[key] = normalized as string | null;
              return value;
            });
            const requestResult = keys.map<KeyValuePair>((key) => [
              key,
              map[key],
            ]);
            const errs = convertErrors(errors);
            callback?.(errs, requestResult);
            resolve(requestResult);
          }
        );
      });
    },

    multiSet: (
      keyValuePairs: [string, string][],
      callback?: MultiCallback
    ): Promise<null> => {
      return new Promise((resolve, reject) => {
        RCTAsyncStorage.multiSet(keyValuePairs, (errors?: ErrorLike[]) => {
          const error = convertErrors(errors);
          callback?.(error);
          if (error) {
            reject(error);
          } else {
            resolve(null);
          }
        });
      });
    },

    multiRemove: (
      keys: readonly string[],
      callback?: MultiCallback
    ): Promise<null> => {
      return new Promise((resolve, reject) => {
        RCTAsyncStorage.multiRemove(keys, (errors?: ErrorLike[]) => {
          const error = convertErrors(errors);
          callback?.(error);
          if (error) {
            reject(error);
          } else {
            resolve(null);
          }
        });
      });
    },

    multiMerge: (
      keyValuePairs: [string, string][],
      callback?: MultiCallback
    ): Promise<null> => {
      return new Promise((resolve, reject) => {
        RCTAsyncStorage.multiMerge(keyValuePairs, (errors?: ErrorLike[]) => {
          const error = convertErrors(errors);
          callback?.(error);
          if (error) {
            reject(error);
          } else {
            resolve(null);
          }
        });
      });
    },
  };
})();

export default AsyncStorage;
